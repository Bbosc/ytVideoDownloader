# ytVideoDownloader
First chrome extension for me, which basically allow a download of the current youtube video in .mp3 format by clicking on the extension icon.


A lot of garbage in the code for sure, as it is a first for me in JS.


